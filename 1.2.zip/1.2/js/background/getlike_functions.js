export const _functions = {
  overlayPopup: (overlayText) => {
    let el = document.querySelector('#bot-liker-popup');
    if (el == null) {
      el = document.createElement('div');
      el.setAttribute("id", "bot-liker-popup");
      document.documentElement.appendChild(el);
    }
    el.innerHTML = `
    <div style="position: fixed;
      top: 0;
      width: 100%;
      height: 100%;
      background-color: rgba(0, 0, 0, .6);
      z-index: 100000">
      <div style="text-align: center;
        max-height: 200px;
        overflow: auto;
        width: min-content;
        margin: 100px auto;
        padding: 10px 30px;
        border-radius: 70px;
        background-image: -moz-linear-gradient(135deg, #ed7934, #db3063 50%, #ad31ae 100%);
        background-image: -webkit-linear-gradient(135deg, #ed7934, #db3063 50%, #ad31ae 100%);
        background-image: -ms-linear-gradient(135deg, #ed7934, #db3063 50%, #ad31ae 100%);
        background-image: linear-gradient(135deg, #ed7934, #db3063 50%, #ad31ae 100%);
        color: #fff;
        font-weight: 700;
        box-shadow: 2px 2px 9px rgba(0, 0, 0, .3);
        flex-direction: initial;
        padding-left: 22px;
        padding-top: 13px"
      >
        <div style="  display: inline-block;width: fit-content"></div> 
        <div style=" display: inline-block;width: max-content;text-align: left;margin-left: 10px;">
          <span class="working">${overlayText}</span>
        </div>
      </div>
    </div>`

  },

  getFirstTaskId : () => {
    return $(".task_item").find("[data-task-id]").data("task-id");
  },

  hideTaskById : (taskId) => {
    $(`#task-item-${taskId}`).remove();
  },

  loadTaskById : async (taskId, baseUrl, version) => {
    baseUrl = baseUrl === undefined ? 'https://getlike.io/tasks' : baseUrl;
    let response = await fetch(`${baseUrl}/do_m/${taskId}/`, {
      method: 'GET',
      headers : {
        'x-requested-with' : 'XMLHttpRequest',
        'x-extension-version': version,
      }
    })
    // {"error":2,"msg":"Для выполнения задания авторизуйтесь в социальной сети \"Ютуб\" (в настройках профиля). Затем попробуйте ещё раз"}
    // {"error":1,"msg":"Выполнение заданий доступно только через расширение. Установите расширение Getlike и выполняйте задания в автоматическом режиме"}
    // {error: 1000, msg: 'Обновите версию расширения для продолжения работы'}
    let data = await response.json();
    if (data?.error !== undefined && data.error > 0) {
      let obj = {
        success: false,
        error: data.error,
        errorMsg: data.msg,
      }
      if (data.error === 1) {
        obj = Object.assign(obj, {error_type_only_for_ext: true})
      } else if (data.error === 2) {
        obj = Object.assign(obj, {error_type_need_auth_soc_net: true})
      } else if (data.error === 1000) {
        obj = Object.assign(obj, {error_type_need_update_ext: true})
      }
      return obj;

      // return false;
    }
    if (data?.url_to_redirect === undefined || data?.url_to_redirect === '') {
      return {
        success: false,
        errorMsg: 'Неверный формат ответа',
        error_type_only_invalid_task: true,
      }
      // return undefined;
    } else {
      return {
        success: true,
        data: data,
      }
      // return data;
    }
    // TODO: сменить ответ на объект (сменить taskObject на объект)
  },

  checkTaskById : async (taskId, baseUrl, version) => {
    let formBody = [
      `id=${taskId}`,
      `count=1`,
      `bot_check=1`,
    ];

    baseUrl = baseUrl === undefined ? 'https://getlike.io/tasks' : baseUrl;
    let response = await fetch(`${baseUrl}/check/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'x-requested-with' : 'XMLHttpRequest',
        'x-extension-version': version,
      },
      body: formBody.join("&")
    });

    let data = await response.json();
    return data?.error;
  },

  clickerCheckTaskById : async (taskId, key, baseUrl, version, keyb = undefined, keyu = undefined) => {
    try {
      throw new Error();
    } catch (e) {}

    let formBody = [
      `id=${taskId}`,
      `key=${encodeURIComponent(btoa(key))}`,
    ];
    if (keyb !== undefined) {
      // formBody.push(`keyb=${encodeURIComponent(btoa(keyb))}`)
      formBody.push(`keyb=${encodeURIComponent(btoa(encodeURIComponent(keyb)))}`)
    }
    if (keyu !== undefined) {
      formBody.push(`keyu=${encodeURIComponent(btoa(keyu))}`)
    }

    baseUrl = baseUrl === undefined ? 'https://getlike.io/tasks' : baseUrl;
    let response = await fetch(`${baseUrl}/clicker_check/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'x-requested-with' : 'XMLHttpRequest',
        'x-extension-version': version,
      },
      body: formBody.join("&")
    });

    let data = await response.json();
    return data?.error;
  },

  skipTaskById : async (taskId, baseUrl, version) => {
    let formBody = [
      `id=${taskId}`,
    ];

    baseUrl = baseUrl === undefined ? 'https://getlike.io/tasks' : baseUrl;
    let response = await fetch(`${baseUrl}/delete/`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'x-requested-with' : 'XMLHttpRequest',
        'x-extension-version': version,
      },
      body: formBody.join("&")
    });
  },

  sendYaEventReachGoal: (event) => {
    injectCode(chrome.runtime.getURL('js/common/injects/sendYaEventReachGoal.js'), event);
  },

  sendExtApiEvent: async (baseUrl, currentVersion, event) => {
    await fetch(`${baseUrl}/extension/events/`, {
      method: 'POST',
      headers: {
        'x-extension-version': currentVersion,
        'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
        'x-requested-with': 'XMLHttpRequest',
      },
      redirect: 'follow',
      body: `event_type=${event}`
    })
  },
}