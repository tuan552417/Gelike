import {Settings} from "./settings.js";

export const debug = async (msg) => {
  // console.log(...msg);
  // let setting = await Settings.getSettings();
  // setting.addLog(msg);
  // let log = await setting.common.log;
  // if (setting.getlike !== undefined && setting.getlike.tab !== undefined) {
  //   try {
  //     setting.getlike.overlayPopup(log);
  //   } catch (e) {}
  // }
  // if (setting.network !== undefined && setting.network.tab !== undefined) {
  //   try {
  //     setting.network.overlayPopup(log);
  //   } catch (e) {}
  // }
}