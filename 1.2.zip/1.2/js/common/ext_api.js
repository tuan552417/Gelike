import {Settings} from "./settings.js";

export class ExtApi {
  static baseUrl = 'https://getlike.io/extension';

  static async request(path, method, headers = {}, additionalOpts = {}) {
    let settings = await Settings.getSettings();
    let currentVersion = await settings.common.version;
    let baseUrl = await settings.getBaseUrl();
    return await fetch(`${baseUrl}/extension/${path}/`,
      Object.assign(
        {
          method: method,
          headers: Object.assign({'x-extension-version': currentVersion}, headers),
        },
        additionalOpts
      ));
  }

  static async checkVersion() {
    try {
      let settings = await Settings.getSettings();
      let response = await this.request('version', 'GET')
      // {
      //   "status": 200,
      //   "success": true,
      //   "data": {
      //      "current": {
      //        "version": "1.0",
      //        "download_link": "https://getlike.io/extension/1.0.zip"
      //      }
      //    }
      // }
      let data = await response.json();
      let currentVersion = await settings.common.version;
      if (data.success && data.data?.current?.version !== currentVersion && data.data?.current?.download_link !== undefined) {
        return {
          download_link: data.data?.current?.download_link,
          version: data.data?.current?.version,
        };
      }
    } catch (e) {}

    return false;
  }

  static async getDocs() {
    let response = await this.request('helpdoc', 'GET', {});
    let data = await response.json();
    if (data.success && data.data?.help?.text !== undefined) {
      return data.data?.help?.text;
    }

    return '';
  }

  static async sendTelegramMessage(text, chatId) {
    if (chatId === undefined || chatId === null || chatId === '') {
      return;
    }

    let formBody = [
      `message=${text}`,
      `chat_id=${chatId}`,
    ];

    this.request('sendtelegrammessage', 'POST', {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
    }, {
      redirect: 'follow',
      credentials: 'omit',
      body: formBody.join("&")
    })
  }

  static async settings(settings = []) {
    this.request('settings', 'POST', {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
    }, {
      redirect: 'follow',
      body: settings.join("&")
    })
  }

  static async event(events = []) {
    let response = await this.request('events', 'POST', {
      'Content-Type': 'application/x-www-form-urlencoded;charset=UTF-8',
      'x-requested-with': 'XMLHttpRequest',
    }, {
      redirect: 'follow',
      body: events.join("&")
    })

    let data = await response.json();
    return data.success;
  }

  static async getPositiveComments() {
    let response = await this.request('commentvariants', 'GET');

    let data = await response.json();
    return data.success
      ? data.data?.comments
      : [];
  }
}