const nullthrows = (v) => {
    if (v == null) throw new Error("it's a null");
    return v;
}

function injectCode(src, dataValue = undefined, isDeleteScript = true) {
    return new Promise((resolve, reject) => {
        const script = document.createElement('script');
        script.src = src;
        if (dataValue !== undefined) {
            script.setAttribute('data-data', dataValue);
        }
        script.onload = function() {
            resolve(this.textContent);
            if (isDeleteScript) {
                this.remove();
            }
        };
        nullthrows(document.documentElement || document.head).appendChild(script);
    })
}

function injectCodeCallback(id, src, callback) {
    const script = document.createElement('script');
    script.setAttribute('id', id);
    script.src = src;
    script.onload = function() {
        callback(this.textContent);
        this.remove();
    };
    //nullthrows(document.head || document.documentElement).appendChild(script);
    //document.documentElement.appendChild(script);
}