var event = document.currentScript.dataset.data;
METRICA_COUNTER.reachGoal(event);